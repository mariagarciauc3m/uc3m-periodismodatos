# APUNTES DE CLASE primer día
## Software
- Código (el propio texto)
- Licencia (lo que dejas o no dejas hacer con el texto)
- Readme (de qué va)

Un REPO (una carpeta donde metes un proyecto, por ejemplo las notas de esta clase) debe tener al menos un readme

## En Markdown: 
- Almohadilla antes de una frase significa título y doble almhoadilla subtítulo
- Asteriscos se convierte comillas
- Dos asteriscos se convierten en negrita

## Para guardar esto:
Lo que se hace es poner comentarios sobre los cambios que haces cuándo guardas, de forma que puedes volver al estado que quieres (rollo google drive que puedes volver a una version antigua del documento)

Main branch- 

Descargar cygwin
Activar con la cuenta de mac
