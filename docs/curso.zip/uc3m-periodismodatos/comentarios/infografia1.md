# COMENTARIO INFOGRAFÍA I
Se trata de una infografía **secuencial**, que busca explicar de forma clara y ordenada una serie de pasos a seguir.  Se sirve de texto e imágenes sencillas y claras para exponer la explicación de otra forma. Así se puede comprender la información a simple vista, y entenderla más en profundidad si se lee el texto. por lo que creo que es una buena forma de representar los datos y que sean comprensibles y útiles para el lector. 

<img width="569" alt="Captura de pantalla 2021-11-09 a las 19 25 43" src="https://user-images.githubusercontent.com/90327355/140982754-3417db28-c8fc-42c1-8d3f-604e802a57ea.png">


