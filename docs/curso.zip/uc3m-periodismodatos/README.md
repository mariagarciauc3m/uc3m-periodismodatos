# PERIODISMO DE DATOS

Notas sobre **periodismo de datos**

## Qué es el periodismo de datos
- Periodismo
- Visualización
- Datos

